Link to the dataset used: 
	https://keras.io/api/datasets/mnist/

Requirements
	keras 
	tensorflow

Set up enviroments
	python -m venv machine-learning 
	source ./machine-learning/bin/activate
	pip install keras
	pip install tensorflow

How to run the code:
	python3 main.py
